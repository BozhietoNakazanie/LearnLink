from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from .core import normalize_text
from .generator import Generator
from aiocache import Cache

app = FastAPI(title="Bulgarian QA Service")
gen = Generator()
cache = Cache(Cache.MEMORY)

class Query(BaseModel):
    question: str

@app.post('/query')
async def query(q: Query):
    text, lang = normalize_text(q.question)
    key = f"q:{text}"
    cached = await cache.get(key)
    if cached:
        return {"answer": cached, "cached": True}
    try:
        answer = await gen.generate(text, None)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    await cache.set(key, answer, ttl=300)
    return {"answer": answer, "cached": False}
