import httpx
from .config import settings

SYSTEM_PROMPT_BG = (
    "Ти си асистент, говориш български. Отговаряй кратко и точно."
)

class Generator:
    def __init__(self):
        self.mode = settings.MODE
        self.openai_key = settings.OPENAI_API_KEY

    async def generate_openai(self, question: str, context: str | None = None) -> str:
        url = "https://api.openai.com/v1/chat/completions"
        headers = {"Authorization": f"Bearer {self.openai_key}"}
        messages = [
            {"role": "system", "content": SYSTEM_PROMPT_BG},
            {"role": "user", "content": (context + "\n---\n" if context else "") + question},
        ]
        payload = {
            "model": settings.GENERATION_MODEL,
            "messages": messages,
            "max_tokens": 400,
            "temperature": 0.0,
        }
        async with httpx.AsyncClient(timeout=10.0) as client:
            r = await client.post(url, json=payload, headers=headers)
            r.raise_for_status()
            data = r.json()
            return data['choices'][0]['message']['content'].strip()

    async def generate(self, question: str, context: str | None = None) -> str:
        if self.mode == 'openai' and self.openai_key:
            return await self.generate_openai(question, context)
        return "(локален отговор) " + question
