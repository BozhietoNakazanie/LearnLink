import re
from langdetect import detect

RE_WHITESPACE = re.compile(r"\s+")

def normalize_text(text: str) -> str:
    text = text.strip()
    text = RE_WHITESPACE.sub(' ', text)
    text = text.replace(' ,', ',').replace(' .', '.')
    try:
        lang = detect(text)
    except Exception:
        lang = 'bg'
    return text, lang
