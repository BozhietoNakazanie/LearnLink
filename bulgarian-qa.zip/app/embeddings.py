from sentence_transformers import SentenceTransformer
import numpy as np
import faiss

class EmbeddingStore:
    def __init__(self, model_name: str):
        self.model = SentenceTransformer(model_name)
        self.index = None
        self.texts = []

    def build(self, docs: list[str]):
        embs = self.model.encode(docs, convert_to_numpy=True)
        dim = embs.shape[1]
        self.index = faiss.IndexFlatL2(dim)
        self.index.add(embs)
        self.texts = docs

    def query(self, q: str, k: int = 5):
        v = self.model.encode([q], convert_to_numpy=True)
        D, I = self.index.search(v, k)
        return [(self.texts[i], float(D[0][j])) for j, i in enumerate(I[0])]
