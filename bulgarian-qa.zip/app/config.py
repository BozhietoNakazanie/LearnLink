from pydantic import BaseSettings

class Settings(BaseSettings):
    MODE: str = "openai"
    OPENAI_API_KEY: str | None = None
    EMBEDDING_MODEL: str = "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"
    GENERATION_MODEL: str = "gpt-3.5-turbo"
    CACHE_TTL: int = 300
    REDIS_URL: str | None = None

    class Config:
        env_file = ".env"

settings = Settings()
