# Bulgarian QA

Леко, бързо API за въпроси на български.

## Стартиране локално

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export OPENAI_API_KEY=...
uvicorn app.main:app --host 0.0.0.0 --port 8000 --workers 4
```

Endpoint: POST /query
